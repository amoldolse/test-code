package com.workscape.vehicleidentifier;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class VehicleDetailsToObject {
	/*
	 * public static void main(String[] args) throws
	 * ParserConfigurationException, IOException, SAXException {
	 * 
	 * System.out.println(parsevehicledetailXML().toString()); }
	 */

	public List<VehicleDetails> parsevehicledetailXML() throws Exception {
		List<VehicleDetails> listVehicleDetails = new ArrayList<VehicleDetails>();
		VehicleDetails vehicleDtls = null;
		Map<String, List<String>> map = null;
		List<String> wheelDetails = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();

		Document document = builder.parse(new File("vehicle.xml"));

		document.getDocumentElement().normalize();

		NodeList nList = document.getElementsByTagName("vehicle");

		for (int temp = 0; temp < nList.getLength(); temp++) {

			Node node = nList.item(temp);

			if (node.getNodeType() == Node.ELEMENT_NODE) {

				Element eElement = (Element) node;
				vehicleDtls = new VehicleDetails();
				vehicleDtls.setId(eElement.getElementsByTagName("id").item(0)
						.getTextContent());
				vehicleDtls.setMaterial(eElement
						.getElementsByTagName("material").item(0)
						.getTextContent());
				wheelDetails = new ArrayList<String>();

				NodeList nList1 = eElement.getElementsByTagName("wheel");

				for (int temp1 = 0; temp1 < nList1.getLength(); temp1++) {

					Node node1 = nList1.item(temp1);

					if (node1.getNodeType() == Node.ELEMENT_NODE) {

						Element eElement1 = (Element) node1;

						wheelDetails.add(eElement1
								.getElementsByTagName("position").item(0)
								.getTextContent());

					}
				}

				map = new HashMap<String, List<String>>();
				map.put(vehicleDtls.getMaterial(), wheelDetails);

				wheelDetails = null;

				vehicleDtls.setWheels(map);

				vehicleDtls
						.setPowertrain(eElement.getElementsByTagName("human")
								.item(0).getTextContent());

				listVehicleDetails.add(vehicleDtls);

			}

		}

		return listVehicleDetails;

	}

	public int getCountOfBigVehicle(List<VehicleDetails> listVehicleDtls) {

		int cntOfBigVehicle = 0;
		for (int i = 0; i < listVehicleDtls.size(); i++) {
			VehicleDetails vehicleDtls = listVehicleDtls.get(i);
			if (vehicleDtls.getMaterial().trim().equalsIgnoreCase("plastic")
					&& vehicleDtls.getPowertrain().trim()
							.equalsIgnoreCase("human")) {
				Map<String, List<String>> map = vehicleDtls.getWheels();
				List<String> wheelsDetails = map.get(vehicleDtls.getMaterial());
				if (wheelsDetails.size() == 3
						&& wheelsDetails.contains("front")
						&& wheelsDetails.contains("rear left")
						&& wheelsDetails.contains("rear right")) {

					cntOfBigVehicle++;
				}
			}
		}
		return cntOfBigVehicle;

	}

	public String getTypeOfVehicle(VehicleDetails vehicleDtls) {

		String typeOfVehicle = "Other";
		
			if (vehicleDtls.getMaterial().trim().equalsIgnoreCase("plastic")
					&& vehicleDtls.getPowertrain().trim()
							.equalsIgnoreCase("human")) {
				Map<String, List<String>> map = vehicleDtls.getWheels();
				List<String> wheelsDetails = map.get(vehicleDtls.getMaterial());
				if (wheelsDetails.size() == 3
						&& wheelsDetails.contains("front")
						&& wheelsDetails.contains("rear left")
						&& wheelsDetails.contains("rear right")) {

					typeOfVehicle = "Big Wheel";
				}
			} else if (vehicleDtls.getMaterial().trim()
					.equalsIgnoreCase("metal")
					&& vehicleDtls.getPowertrain().trim()
							.equalsIgnoreCase("human")) {
				Map<String, List<String>> map = vehicleDtls.getWheels();
				List<String> wheelsDetails = map.get(vehicleDtls.getMaterial());
				if (wheelsDetails.size() == 2
						&& wheelsDetails.contains("front")
						&& wheelsDetails.contains("rear")) {

					typeOfVehicle = "ByCycle";
				}
			} else if (vehicleDtls.getMaterial().trim()
					.equalsIgnoreCase("metal")
					&& vehicleDtls.getPowertrain().trim()
							.equalsIgnoreCase("internal combustion")) {
				Map<String, List<String>> map = vehicleDtls.getWheels();
				List<String> wheelsDetails = map.get(vehicleDtls.getMaterial());
				if (wheelsDetails.size() == 2
						&& wheelsDetails.contains("front")
						&& wheelsDetails.contains("rear")) {

					typeOfVehicle = "MotorCycle";
				}
			}

		
		return typeOfVehicle;

		// return cntOfBigVehicle;

	}

	public int getCountOfBycycle(List<VehicleDetails> listVehicleDtls) {

		int cntOfbycycle = 0;
		for (int i = 0; i < listVehicleDtls.size(); i++) {
			VehicleDetails vehicleDtls = listVehicleDtls.get(i);
			if (vehicleDtls.getMaterial().trim().equalsIgnoreCase("metal")
					&& vehicleDtls.getPowertrain().trim()
							.equalsIgnoreCase("human")) {
				Map<String, List<String>> map = vehicleDtls.getWheels();
				List<String> wheelsDetails = map.get(vehicleDtls.getMaterial());
				if (wheelsDetails.size() == 2
						&& wheelsDetails.contains("front")
						&& wheelsDetails.contains("rear")) {

					cntOfbycycle++;
				}
			}
		}
		return cntOfbycycle;

	}

	public int getCountOfMotorCycle(List<VehicleDetails> listVehicleDtls) {

		int cntOfmotorCycle = 0;
		for (int i = 0; i < listVehicleDtls.size(); i++) {
			VehicleDetails vehicleDtls = listVehicleDtls.get(i);
			if (vehicleDtls.getMaterial().trim().equalsIgnoreCase("metal")
					&& vehicleDtls.getPowertrain().trim()
							.equalsIgnoreCase("internal combustion")) {
				Map<String, List<String>> map = vehicleDtls.getWheels();
				List<String> wheelsDetails = map.get(vehicleDtls.getMaterial());
				if (wheelsDetails.size() == 2
						&& wheelsDetails.contains("front")
						&& wheelsDetails.contains("rear")) {

					cntOfmotorCycle++;
				}
			}
		}
		return cntOfmotorCycle;

	}
}
