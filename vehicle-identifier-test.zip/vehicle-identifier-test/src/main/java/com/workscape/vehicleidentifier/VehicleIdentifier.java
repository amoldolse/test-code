package com.workscape.vehicleidentifier;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.ParserConfigurationException;

import org.junit.Test;
import org.xml.sax.SAXException;

/**
 * Hello world!
 * 
 */
public class VehicleIdentifier {
	@Test
	public void testvehicle() {
	
		VehicleDetailsToObject vehicleDetailsToObject = new VehicleDetailsToObject();
		
		try {
			System.out.println(vehicleDetailsToObject.parsevehicledetailXML().toString());
			List<VehicleDetails> listvehicleDtls = vehicleDetailsToObject.parsevehicledetailXML();
			System.out.println("===== count of big wheel vehicle provided in xml  is = "+vehicleDetailsToObject.getCountOfBigVehicle(listvehicleDtls));
			
			System.out.println("===== count of ByCycle provided in xml  is = "+vehicleDetailsToObject.getCountOfBycycle(listvehicleDtls));
			
			System.out.println("===== count of Motorcycle provided in xml  is = "+vehicleDetailsToObject.getCountOfMotorCycle(listvehicleDtls));
			
			assertEquals(2,listvehicleDtls.size());
			
			assertEquals(1, vehicleDetailsToObject.getCountOfBigVehicle(listvehicleDtls));
			
			VehicleDetails details = new VehicleDetails();
			details.setMaterial("metal");
			details.setPowertrain("human");
			List<String> wheelList = new ArrayList<String>();
			wheelList.add("front");
			wheelList.add("rear");
			
			 Map map = new HashMap<String, List<String>>();
			map.put(details.getMaterial(), wheelList);
			details.setWheels(map);
			
			assertEquals("ByCycle", vehicleDetailsToObject.getTypeOfVehicle(details));
			
			System.out.println(" type of vehicle and vehicle id for below details is ="+vehicleDetailsToObject.getTypeOfVehicle(details));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
}
