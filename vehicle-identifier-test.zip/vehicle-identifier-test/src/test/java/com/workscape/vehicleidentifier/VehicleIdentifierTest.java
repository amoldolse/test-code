package com.workscape.vehicleidentifier;


import static junit.framework.Assert.fail;

import javax.xml.transform.Result;

import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.notification.Failure;

/**
 * Unit test for simple App.
 */
public class VehicleIdentifierTest {

	
	/**
	 * Rigorous Test :-)
	 */
	@Test
	public void testApp() {
		org.junit.runner.Result result = JUnitCore.runClasses(VehicleIdentifier.class);
		
		for(Failure fail :result.getFailures()){
			
			System.out.println("fail test cases = "+fail.toString());
		}
		
		System.out.println(" succesfull "+result.wasSuccessful());
		
	}
}
