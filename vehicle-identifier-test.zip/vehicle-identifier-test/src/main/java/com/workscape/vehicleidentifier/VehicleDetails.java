package com.workscape.vehicleidentifier;

import java.util.List;
import java.util.Map;

public class VehicleDetails {

	private String id;
	
	private String material;
	
	private Map<String,List<String>> wheels;
	
	private String powertrain;

	public String getId() {
		return id;
	}

	public void setId(String string) {
		this.id = string;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getPowertrain() {
		return powertrain;
	}

	public void setPowertrain(String powertrain) {
		this.powertrain = powertrain;
	}

	
	
	public Map<String,List<String>> getWheels() {
		return wheels;
	}

	public void setWheels(Map<String,List<String>> wheels) {
		this.wheels = wheels;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		//return super.toString();
		
		return "vehicle id = "+this.id+"material = "+this.material+" powertrain ="+this.powertrain+"+wheels details = "+this.getWheels().toString();
	}
}
